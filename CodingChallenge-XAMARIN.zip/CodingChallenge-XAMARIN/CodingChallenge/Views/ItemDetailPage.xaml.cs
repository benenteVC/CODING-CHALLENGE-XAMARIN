﻿using CodingChallenge.ViewModels;
using System.ComponentModel;
using Xamarin.Forms;

namespace CodingChallenge.Views
{
    public partial class ItemDetailPage : ContentPage
    {
        public ItemDetailPage()
        {
            InitializeComponent();
            BindingContext = new ItemDetailViewModel();
        }
    }
}