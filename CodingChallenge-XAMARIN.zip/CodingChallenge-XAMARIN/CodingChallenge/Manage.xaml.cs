﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace CodingChallenge
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Manage : ContentPage
    {
        public Manage()
        {
            InitializeComponent();
        }

        // Text Fill - Character set to no greater than 200
        public class CharacterCount : Behavior<Entry>
        {
            // Limit set to 200
            public int TextLenght { get; set; } = 200;

            protected override void OnAttachedTo(Entry bindable)
            {
                base.OnAttachedTo(bindable);
                bindable.TextChanged += TextChanged;
            }

            private void TextChanged(object sender, TextChangedEventArgs e)
            {
                // if the text area has been left empty
                if (string.IsNullOrEmpty(e.NewTextValue))
                    return;

                if (e.NewTextValue.Length >= TextLenght)
                    ((Entry)sender).Text = e.OldTextValue;
            }

            protected override void OnDetachingFrom(Entry bindable)
            {
                bindable.TextChanged -= TextChanged;
            }
        }

        // Switch to state if the user is active or not
        private void Switch_Toggled(object sender, ToggledEventArgs e)
        {
            bool isToggled = e.Value;

            MainSwitch.BindingContext = isToggled.ToString();
        }

        void OnNavigationFailed(object sender, CharacterCount e)
        {
            throw new Exception("Sorry, You have exceeded the word limit ");
        }

        private class Presents
        {
            public Presents()
            {

            }
        }

        // Upload an Image from Photo Gallery
        async void Image_Clicked(object sender, EventArgs e)
        {
            var result = await MediaPicker.PickPhotoAsync(new MediaPickerOptions
            {
                Title = "Please choose an Image"
            });

            if (result == null)
            {
                var stream = await result.OpenReadAsync();

                resultImage.Source = ImageSource.FromStream(() => stream);
            }
        }

        // Take an image on the camera
        async void ImageTake_Clicked(object sender, EventArgs e)
        {
            var result = await MediaPicker.CapturePhotoAsync();

            if (result != null)
            {
                var stream = await result.OpenReadAsync();

                resultImage.Source = ImageSource.FromStream(() => stream);
            }
        }
    }