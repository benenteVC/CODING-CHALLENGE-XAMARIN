﻿namespace CodingChallenge
{
    internal class SuspendingEventArgs
    {
        public object NavigationOperation { get; internal set; }
    }
}