﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace CodingChallenge
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Present : ContentPage
    {


    public Present()
        {
            InitializeComponent();
        }

        // X button to close the page and head back to main page
        private async void Exit_button(object sender, ToggledEventArgs e)
        {
                await Navigation.PushAsync(new HomePage());
        }
    }
}