﻿namespace CodingChallenge
{
    internal class CharacterCount
    {
        public string Wordcount { get; internal set; }
    }
}